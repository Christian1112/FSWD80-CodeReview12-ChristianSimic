<?php get_header(); ?>
  <div class="container-fluid">
    <div class="blog-header">
      <h1 class="blog-title"><?php bloginfo('name'); ?></h1>
      <p class="lead blog-description"><?php bloginfo('description'); ?></p>
    </div>
    <hr>
    <div class="container">
      <div class="categoryheader">
        <h3>You are browsing the category <b><?php $cat = get_the_category(); echo $cat[0]->cat_name; ?></b>!</h3>
      </div>
      <div class="row">
        <?php if(have_posts()) :  ?>
        <?php while(have_posts()) : the_post(); ?>
        <div class="col-xs-12 col-sm-6 col-md-6 col-lg-4">
          <div class="post">
            <div class="postthumbnail">
              <a href="<?php the_permalink(); ?>">
                <?php if(has_post_thumbnail()) : ?>
                <?php the_post_thumbnail(); ?>
                <?php endif; ?>
              </a>
            </div>
            <div class="postcategory">
              <?php $cat = get_the_category(); echo $cat[0]->cat_name; ?>
            </div>
            <div class="posttitle">
              <a href="<?php the_permalink(); ?>"><h2><?php the_title(); ?></h2></a>
            </div>
            <div class="postcontent">
              <?php the_excerpt(); ?>
            </div>
            <div class="postdate">
              <?php the_time('F j, Y'); ?>
            </div>
          </div> <!-- end of post -->
        </div> <!-- end of col -->
        <?php endwhile; ?>
        <?php else : ?>
        <p><?php__('Sorry no posts in this category found!'); ?></p>
        <?php endif; ?>
      </div> <!-- end of row -->
    </div> <!-- end of container -->
  </div> <!-- end of container-fluid --> 
<?php get_footer(); ?>