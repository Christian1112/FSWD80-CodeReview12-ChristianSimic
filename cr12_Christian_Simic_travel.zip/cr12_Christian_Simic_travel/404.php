<?php get_header(); ?>
  <div class="container-fluid">
    <div class="blog-header">
      <h1 class="blog-title"><?php bloginfo('name'); ?></h1>
      <p class="lead blog-description"><?php bloginfo('description'); ?></p>
    </div>
    <hr>
    <div class="container">
      <div class="error404">
        <h2>Something went wrong</h2>
        <h3>Please click on another site!</h3>
        <h1>404</h1>
        <h2>page does not exist</h2>
      </div>
    </div>
  </div>  
<?php get_footer(); ?>